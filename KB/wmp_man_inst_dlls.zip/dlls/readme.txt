These files are meant to be the package suggested in this blog entry: 

Manually Installing Windows Media Player Plugin for Firefox in Windows Vista

URL: http://banagale.com/manually-installing-windows-media-player-plugin-for-firefox-in-windows-vista.htm

These DLLs were collected from various ad-supported dll websites.  They have not been independently verified, use at your own risk.

Also, please be kind to others.

rob banagale