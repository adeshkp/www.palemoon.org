All logos in this archive are Copyrighted and Trademarked.
The Pale Moon logo is the property of M.C. Straver BASc. All rights reserved.

For permissions and acceptable use guidelines for these logo images
please see http://www.palemoon.org/branding.shtml
